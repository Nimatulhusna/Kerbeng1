import paramiko
import time

from datetime import datetime
from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect
from django.db import connections

from .models import Device, Log

# Create your views here.

curs = connections['kb_a'].cursor()

def home(request):
    all_device = Device.objects.all()
    devices = Device.objects.all()
    last_event = Log.objects.all().order_by('-id')[:10]
    
    curs.execute('select * from hn_mach')
    dat = curs.fetchall()
    
    sttm = ""
    
    if dat == [[]]:
        sttm = "There is no honeypot installed, deploy a new one...."
    else:
        sttm = ""
    context = {
        'all_device': len(all_device),
        'last_event': last_event,
        'devices': devices,
        'dat': dat,
        'sttm': sttm
        #'mode': 'Verify Config'
    }

    return render(request, 'home.html', context)


# def devices(request):
    # all_device = Device.objects.all()

    # context = {
        # 'devices': all_device
    # }

    # return render(request, 'devices.html', context)

def log(request):
    log_text = Log.objects.all()

    context = {
        'logs': log_text
    }

    return render(request, 'log.html', context)


def deploy(request):
    if request.method == "POST" and request.POST['submit'] == "Submit":
        result = []
        error  = []
        rdjs = ""#curs.execute("select link from repository where name like '%dioJson%' and status=valid")
        rle2 = ""
        rled = ""
        rdio = ""
        other_command = request.POST['other_command'].splitlines()
        name = request.POST['name']
        loc = request.POST['loc']
        platform = request.POST['platform']
        ip = request.POST['ip']
        user = request.POST['user']
        passw = request.POST['passw']
        r_user = request.POST['r_user']
        r_pass = request.POST['r_pass']
        hname = request.POST['hname']
        htyp = request.POST['htyp']
        a_start = request.POST['a_start']
        comm = ["cmake -DCMAKE_INSTALL_PREFIX:PATH=/opt/dionaea ..",
                "make",
                "make install"]
        jlog = ['cd /opt/dionaea/etc/dionaea/ihandlers-available/', 'cp log_json.yaml /opt/dionaea/etc/dionaea/ihandlers-enabled',
                'wget https://raw.githubusercontent.com/Nimatulhusna/Kerbeng1/main/dionaeaSqliteToJson.py', 'mv dionaeaSqliteToJson.py /opt/',
                '(crontab -l 2>/dev/null || true; echo "*/1 * * * * /usr/bin/python3 /opt/dionaeaSqliteToJson.py") | crontab -', 'cd /',
                'setcap CAP_NET_BIND_SERVICE=+eip /opt/dionaea/bin/dionaea']
        serv = ["touch dionaea.service",
                "echo '[Unit]' >> dionaea.service",
                "echo 'Description=honeypot dionaea service' >> dionaea.service",
                "echo 'After=network.target' >> dionaea.service",
                "echo 'StartLimitIntervalSec=0' >> dionaea.service",
                "echo '' >> dionaea.service",
                "echo '[Service]' >> dionaea.service",
                "echo 'Type=simple' >> dionaea.service",
                "echo 'Restart=on-failure' >> dionaea.service",
                "echo 'RestartSec=3' >> dionaea.service",
                "echo 'User=root' >> dionaea.service",
                """echo "ExecStart=/opt/dionaea/bin/dionaea -l all,-debug -L '*'" >> dionaea.service""",
                "echo '' >> dionaea.service",
                "echo '[Install]' >> dionaea.service",
                "echo 'WantedBy=multi-user.target' >> dionaea.service",
                "cp dionaea.service /etc/systemd/system",
                "cp dionaea.service /lib/systemd/system",
                "cp dionaea.service /usr/lib/systemd/system",
                "systemctl daemon-reload"]
        strt = ["systemctl start dionaea",
                "systemctl enable dionaea"]
        
        if len(other_command) != 0:
            try:
                ssh_client = paramiko.SSHClient()
                ssh_client.set_missing_host_key_policy(
                    paramiko.AutoAddPolicy())
                ssh_client.connect(hostname=ip,
                                   username=r_user, password=r_pass)
                conn = ssh_client.invoke_shell()
                # for cmd in other_command:
                            # stdin, stdout, stderr = ssh_client.exec_command(cmd)
                            # time.sleep(1)
                            # result.append("Result on {0}".format('10.33.102.247'))
                            # result.append(stdout.read().decode())
                for cmd in other_command:
                    #result.append("Result on {0}".format('10.33.102.247'))
                    stdin, stdout, stderr = ssh_client.exec_command(cmd + "\n")
                    #conn.send(cmd + "\n")
                    time.sleep(1)
                    output = conn.recv(65535)
                    result.append(output.decode())
                    result.append(stdout.read().decode())
                    result.append(stderr.read().decode())
                ssh_client.close()
                log = Log(target=ip, action="Verify Configuration",
                          status="Success", time=datetime.now(), messages="Nice Run")
                log.save()
            except Exception as e:
                log = Log(target=ip, action="Verify Configuration",
                          status="Error", time=datetime.now(), messages=e)
                log.save()

            result = '\n'.join(result)
            return render(request, 'verify_result.html', {'result': result})
        
        
        elif htyp != "0":
            curs.execute("select script from repository where type='packages' and os='any' and label='"+htyp+"'")
            pkg = curs.fetchall()
            curs.execute("select script from repository where type='packages' and os='"+platform+"' and label='"+htyp+"'")
            addi = curs.fetchall()
            ssh_client = paramiko.SSHClient()
            ssh_client.set_missing_host_key_policy(
                paramiko.AutoAddPolicy())
            ssh_client.connect(hostname=ip,
                               username=r_user, password=r_pass)
            conn = ssh_client.invoke_shell()
            
            #condat = str()
            
            def step1():
                condat = str()
                while True:
                    if conn.recv_ready():
                        condat += conn.recv(65535).decode()
                    else:
                        continue
                    if condat.endswith('$ '):
                        conn.send("sudo -s" + "\n")
                        time.sleep(1)
                    elif condat.endswith(': '):
                        conn.send(passw + "\n")
                        time.sleep(1)
                    elif condat.endswith('# '):
                        break
                return condat
            
            def step2():
                condat = str()
                for cmd in pkg:
                    conn.send(cmd[0] + "\n")
                    time.sleep(1)
                    while True:
                        if conn.recv_ready():
                            condat += conn.recv(65535).decode()
                        else:
                            continue
                        if condat.endswith('# '):
                            break
                if addi != [[]]:
                    for addt in addi:
                        conn.send(addt + "\n")
                        time.sleep(1)
                        while True:
                            if conn.recv_ready():
                                condat += conn.recv(65535).decode()
                            else:
                                continue
                            if condat.endswith('# '):
                                break
                    return condat
                else:
                    return condat
                
            def step3():
                condat = str()
                curs.execute("select script from repository where type='setup' and label='"+htyp+"'")
                setup = curs.fetchall()
                conn.send(setup[0][0] + "\n")
                time.sleep(1)
                while True:
                    if conn.recv_ready():
                        condat += conn.recv(65535).decode()
                    else:
                        continue
                    if condat.endswith('# '):
                        break
                conn.send("echo 'next'" + "\n")
                time.sleep(1)
                condat += conn.recv(65535).decode()
                return condat
            
            def step4():
                condat = str()
                conn.send("cd dionaea" + "\n")
                time.sleep(1)
                conn.send("mkdir build" + "\n")
                time.sleep(1)
                conn.send("cd build" + "\n")
                time.sleep(1)
                for cmmd in comm:
                    conn.send(cmmd + "\n")
                    time.sleep(1)
                    while True:
                        if conn.recv_ready():
                            condat += conn.recv(65535).decode()
                        else:
                            continue
                        if condat.endswith('# '):
                            break
                conn.send("cd /home" + "\n")
                condat += conn.recv(65535).decode()
                return condat
            
            def step5():
                condat = str()
                conn.send("select-editor" + "\n")
                time.sleep(1)
                conn.send("1" + "\n")
                time.sleep(1)
                for jlogg in jlog:
                    conn.send(jlogg + '\n')
                    time.sleep(1)
                    while True:
                        if conn.recv_ready():
                            condat += conn.recv(65535).decode()
                        else:
                            continue
                        if condat.endswith('# '):
                            break
                conn.send("cd /home" + "\n")
                condat += conn.recv(65535).decode()
                return condat
            
            def step6():
                condat = str()
                for srv in serv:
                    conn.send(srv + "\n")
                    time.sleep(1)
                    while True:
                        if conn.recv_ready():
                            condat += conn.recv(65535).decode()
                        else:
                            continue
                        if condat.endswith('# '):
                            break
                if a_start == "0":
                    return condat
                elif a_start == "a_start":
                    for st in strt:
                        conn.send(st + "\n")
                        time.sleep(1)
                        while True:
                            if conn.recv_ready():
                                condat += conn.recv(65535).decode()
                            else:
                                continue
                            if condat.endswith('# '):
                                break
                    return condat
            
            result.append(htyp)
            
            s1 = step1()
            time.sleep(1)
            s2 = step2()
            time.sleep(1)
            s3 = step3()
            time.sleep(1)
            s4 = step4()
            time.sleep(1)
            s5 = step5()
            time.sleep(1)
            s6 = step6()
            time.sleep(1)
            
            result.append(s1)
            result.append(s2)
            result.append(s3)
            result.append(s4)
            result.append(s5)
            result.append(s6)
            
            ssh_client.close()
            if error == []:
                log = Log(target=ip, action="Verify Configuration",
                          status="Installation Succeed", time=datetime.now(), messages="Nice Run")
                log.save()
            else:
                log = Log(target=ip, action="Verify Configuration",
                          status="Installation Error", time=datetime.now(), messages="Error Detected")
                log.save()
            
            return render(request, 'verify_result.html', {'result': result}) 

    elif request.method == "POST" and request.POST['submit'] == "Save":
        name = request.POST['name']
        loc = request.POST['loc']
        platform = request.POST['platform']
        if platform == "ubuntu-18":
            platform = "Ubuntu 18.04 or below"
        elif platform == "ubuntu+20":
            platform = "Ubuntu 20.04 and above"
        ip  = request.POST['ip']
        user  = request.POST['user']
        passw   = request.POST['passw']
        r_user  = request.POST['r_user']
        r_pass   = request.POST['r_pass']
        ins = "INSERT INTO `machine` (`id`, `name`, `location`, `platform`, `ip`, `user`, `passw`, `r_user`, `r_pass`, `status`) VALUES (NULL, '"
        sep = "', '"
        
        ssh_client = paramiko.SSHClient()
        ssh_client.set_missing_host_key_policy(
            paramiko.AutoAddPolicy())
        ssh_client.connect(hostname=ip,
                           username=r_user, password=r_pass)
        conn = ssh_client.invoke_shell()
        sttm = ""
        
        condat = str()
        stat = "inactive"
        while True:
            if conn.recv_ready():
                condat += conn.recv(65535).decode()
            else:
                continue
            if condat.endswith('$ '):
                conn.send("sudo -s" + "\n")
                time.sleep(1)
            elif condat.endswith(': '):
                conn.send(passw + "\n")
                time.sleep(1)
            elif condat.endswith('# '):
                stat = "active"
                break
            else:
                stat = "inactive"
                break
        if stat == "active":
            curs.execute(ins+name+sep+loc+sep+platform+sep+ip+sep+user+"', PASSWORD('"+passw+"'), '"+r_user+"', PASSWORD('"+r_pass+"'), '"+stat+"')")
        else:
            sttm = "Can't save new machine due to machine state is inactive or incorrect username/password"
        
        devices = Device.objects.all()
        all_device = Device.objects.all()
        last_event = Log.objects.all().order_by('-id')[:10]
        curs.execute('select * from machine')
        dat = curs.fetchall()
        
        if dat == [[]]:
            sttm = "There is no machine saved, add a new one...."
        else:
            sttm = ""
        context = {
            'all_device': len(all_device),
            'last_event': last_event,
            'devices': devices,
            'dat': dat,
            'stat': stat,
            'sttm': sttm,
            'mode': 'Verify Config'
        }
        return render(request, 'deploy.html', context)

    else:
        devices = Device.objects.all()
        all_device = Device.objects.all()
        last_event = Log.objects.all().order_by('-id')[:10]
        curs.execute('select * from machine')
        dat = curs.fetchall()
        
        sttm = ""
        
        if dat == [[]]:
            sttm = "There is no machine saved, add a new one...."
        else:
            sttm = ""
        context = {
            'all_device': len(all_device),
            'last_event': last_event,
            'devices': devices,
            'dat': dat,
            'sttm': sttm,
            'mode': 'Verify Config'
        }
        return render(request, 'deploy.html', context)
        

def about(request):
    return render(request, 'about.html')

def verify_result(request):
    return render(request, 'verify_result.html')